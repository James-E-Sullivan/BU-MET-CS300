'''
Intent: Begin to provide options for the form of one person to be addressed.

Postconditions: The following are on the console (excluding the numbering):
1.
Greetings from a beginning Python programmer.
2.
Do you want to be addressed as ...
.......................................======>Jane Margaret Doe?
.......................................======>Jane Doe?
.......................................======>Mr./Ms. Jane Margaret Doe?
.......................................======>Dear Jane?
or 
.......................................======>Doe, Jane Margaret?
3.
After a blank line, the same output, but applied to Archibald Montague
Abercrombie
4.
After a blank line, the same output, but applied to Cleopatra Anastasia
Montgomery
'''

# New variable, greeting, assigned greeting string.
greeting = "\nGreetings from a beginning Python programmer. \n\
Do you want to be addressed as ..."

arrow = ".......................................======>"

# The greeting string is printed to the console.
print(greeting)

# Options for Jane Margaret Doe printed to the console.
print("\n" + arrow + "Jane Margaret Doe?")
print(arrow + "Jane Doe?")
print(arrow + "Mr./Ms. Jane Margaret Doe?")
print(arrow + "Dear Jane?")
print("or")
print(arrow + "Doe, Jane Margaret?")

# Options for Archibald Montague Abercrombie printed to console.
print("\n" + arrow + "Archibald Montague Abercrombie?")
print(arrow + "Archibald Abercrombie?")
print(arrow + "Mr./Ms. Archibald Montague Abercrombie?")
print(arrow + "Dear Archibald?")
print("or")
print(arrow + "Abercrombie, Archibald Montague?")

# Options for Cleopatra Anastasia Montgomery printed to console.
print("\n" + arrow + "Cleopatra Anastasia Montgomery?")
print(arrow + "Cleopatra Anastasia Montgomery?")
print(arrow + "Mr./Ms. Cleopatra Anastasia Montgomery?")
print(arrow + "Dear Cleopatra?")
print("or")
print(arrow + "Montgomery, Cleopatra Anastasia?")
