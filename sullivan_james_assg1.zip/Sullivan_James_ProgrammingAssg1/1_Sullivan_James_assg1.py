'''
Intent: Begin to provide options for the form of people to be addressed.

Postcondition:
The following is on the console (i.e., preceded by a blank line):

Greetings from a beginning Python programmer.
Do you want to be addressed as ...
'''

# New variable, greeting, assigned greeting string.
greeting = "\nGreetings from a beginning Python programmer. \n\
Do you want to be addressed as ..."

# The greeting string is printed to the console.
print(greeting)
