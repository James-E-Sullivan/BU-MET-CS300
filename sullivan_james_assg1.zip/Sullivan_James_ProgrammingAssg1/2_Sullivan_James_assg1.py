'''
Intent: Begin to provide options for the form of one person to be addressed.

Postconditions: The following are on the console (excluding the numbering):
1.
Greetings from a beginning Python programmer.
2.
Do you want to be addressed as ...
.......................................======>Jane Margaret Doe?
.......................................======>Jane Doe?
.......................................======>Mr./Ms. Jane Margaret Doe?
.......................................======>Dear Jane?
or 
.......................................======>Doe, Jane Margaret?
'''

# New variable, greeting, assigned greeting string.
greeting = "\nGreetings from a beginning Python programmer. \n\
Do you want to be addressed as ..."

arrow = ".......................................======>"

# The greeting string is printed to the console.
print(greeting)

# Options for the user are printed to the console.
print(arrow + "Jane Margaret Doe?")
print(arrow + "Jane Doe?")
print(arrow + "Mr./Ms. Jane Margaret Doe?")
print(arrow + "Dear Jane?")
print("or")
print(arrow + "Doe, Jane Margaret?")
