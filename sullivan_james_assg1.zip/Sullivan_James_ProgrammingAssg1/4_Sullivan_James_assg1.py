'''
Intent: Begin to provide options for the form of one person to be addressed.

Postconditions: The following are on the console (excluding the numbering):
1.
Greetings from a beginning Python programmer.
2.
Do you want to be addressed as ...
.......................................======>Jane Margaret Doe?
.......................................======>Jane Doe?
.......................................======>Mr./Ms. Jane Margaret Doe?
.......................................======>Dear Jane?
or 
.......................................======>Doe, Jane Margaret?
3.
After a blank line, the same output, but applied to Archibald Montague
Abercrombie
4.
After a blank line, the same output, but applied to Cleopatra Anastasia
Montgomery
'''

# New variable, greeting, assigned greeting string.
greeting = "\nGreetings from a beginning Python programmer. \n\
Do you want to be addressed as ..."

arrow = ".......................................======>"

# The greeting string is printed to the console.
print(greeting)

# Options for Jane Margaret Doe printed to the console.
print("\n{3}{0} {1} {2}?\n\
{3}{0} {2}?\n\
{3}Mr./Ms. {0} {1} {2}?\n\
{3}Dear {0}?\n\
or\n\
{3}{2}, {0} {1}".format("Jane","Margaret","Doe", arrow))

# Options for Archibald Montague Abercrombie printed to console.
print("\n{3}{0} {1} {2}?\n\
{3}{0} {2}?\n\
{3}Mr./Ms. {0} {1} {2}?\n\
{3}Dear {0}?\n\
or\n\
{3}{2}, {0} {1}".format("Archibald","Montague","Abercrombie", arrow))

# Options for Cleopatra Anastasia Montgomery printed to console.
print("\n{3}{0} {1} {2}?\n\
{3}{0} {2}?\n\
{3}Mr./Ms. {0} {1} {2}?\n\
{3}Dear {0}?\n\
or\n\
{3}{2}, {0} {1}".format("Cleopatra","Anastasia","Montgomery", arrow))
