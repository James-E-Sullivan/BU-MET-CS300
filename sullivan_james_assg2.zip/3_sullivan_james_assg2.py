'''
Postconditions
1. (Welcome): A welcome message is on the console
2. (Complaint): A complaint was entered by the user in response to a prompt
3. (Duration): A duration was entered by user in response to a prompt
4. (Error Check): EITHER the user entered an integer between 1 and 100 for
duration after being given up to two chances OR the application quit after
suggesting a re-run.
5. (Action Recommended): EITHER how long exceeds 2 months, and the phrase
    "... months is too much time to go without help! Let's schedule a few
    sessions"
    is on the console
    OR the following is on the console:
    "Come back in a couple of months if this persists".
'''

import sys

# Prints a welcome message and user prompt to the console
print("Thank you for using Eliza300, a fun therapy program.")
print("Please state your emotional complaint then hit ENTER:")

# Keyboard input from user is stored as variable 'complaint'
complaint = input()

# Prints a prompt for user to enter duration of complaint
print("How many months have you experienced '" + complaint + "'?")

# Input from user is stored as variable 'months'
months = input()

# Declares a variable to store the number of bad user inputs
badAttempts = 0

# This loop first checks to make sure the user input a number
# Then this loop checks if the input number is between 1 and 100 (inclusive)
# After 1 bad attempt, Eliza tells user that they can try one more time
# After 2 bad attempts, Eliza exits the program
while True:
    try:
        if int(months) < 1 or int(months) > 100:
            if badAttempts == 0:
                print("Outside of range. Please try one more time to enter"
                      + " duration in months less than 100.")
                months = input()
                badAttempts += 1
            else:
                print("Outside of range. Sorry, try running Eliza300 again.")
                sys.exit()
        else:
            break
    except ValueError:
        if badAttempts == 0:
            print("That is not a number. Please try one more time to enter"
                  + " duration in months less than 100.")
            months = input()
            badAttempts += 1
        else:
            print("That is not a number. Sorry, try running Eliza300 again.")
            sys.exit()

# Evaluates whether the user has gone too long without help
# Prints recommendation to schedule a session or to wait,
# based on the value of 'months'
if int(months) > 2:
    print(str(months) + " months is too much time to go without help!"
          " Let's schedule a few sessions.")
else:
    print("Come back in a couple of months if this persists.")
