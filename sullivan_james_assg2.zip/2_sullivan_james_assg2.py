'''
Postconditions
1. (Welcome): A welcome message is on the console
2. (Complaint): A complaint was entered by the user in response to a prompt
3. (Duration): A duration was entered by user in response to a prompt
4. (Action Recommended): EITHER how long exceeds 2 months, and the phrase
    "... months is too much time to go without help! Let's schedule a few
    sessions"
    is on the console
    OR the following is on the console:
    "Come back in a couple of months if this persists".
'''

# Prints a welcome message and user prompt to the console
print("Thank you for using Eliza300, a fun therapy program.")
print("Please state your emotional complaint then hit ENTER:")

# Keyboard input from user is stored as variable 'complaint'
complaint = input()

# Prints a prompt for user to enter duration of complaint
print("How many months have you experienced '" + complaint + "'?")

# Input from user is converted to int & stored as variable 'months'
months = int(input())

# Evaluates whether the user has gone too long without help.
# Prints recommendation to schedule a session or to wait,
# based on the value of 'months'
if months > 2:
    print(str(months) + " months is too much time to go without help!"
          + " Let's schedule a few sessions.")
else:
    print("Come back in a couple of months if this persists.")
