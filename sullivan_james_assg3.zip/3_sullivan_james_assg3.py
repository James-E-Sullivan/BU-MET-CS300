# Eliza300
# Intent: A list of helpful actions that a troubled person could take. Build 3

import sys

possible_actions = ['taking up yoga', 'sleeping eight hours a night',
                    'relaxing', 'not working on weekends',
                    'spending two hours a day with friends']

'''
Precondition: possible_actions is the list defined above

Postconditions:
1. (Welcome): A welcome message is on the console

2. (user_complaint): user_complaint is the user's response to
"Please describe your emotional complaint--in one punctuation-free line: "

3. (how_long): how_long is the user's response to
"How many months (between 1 and 99) have you experienced ...?"

4. (Month validity): EITHER how_long has the requested form
OR this terminated AND "Sorry, illegal input. Eliza is quitting; run Eliza again."
is on the console

5. (Advice): EITHER how_long >= 3
OR "Please return in * months" is on the console where * is 3 - how_long

6. (actions_not_taken): actions_not_taken consists of the actions (elements) in
possible_actions that the user answered 'n' to when questioned "Have you tried..."

7. (Summarized): Eliza300 recommended that the user take the actions in
actions_not_taken
'''

# Welcome message from Eliza300 is printed on the console
print("Thank you for using Eliza300, a fun therapy program.")

# User prompted to input their emotional complaint
# User complaint stored as string in variable 'user_complaint'
print("Please describe your emotional complaint--in one punctuation-free line: ")
user_complaint = input()

# User prompted to input number of months they have experienced their complaint
# User input stored as string in variable 'how_long'
print("How many months (between 1 and 99) have you experienced '"\
      + user_complaint + "'?")
how_long = input()

if int(how_long) < 1 or int(how_long) > 99:
    print("Sorry, illegal input. Eliza is quitting; run Eliza again.")
    sys.exit()

# Eliza300 sympathetic response, mentioning duration, printed to console
print(how_long + " months is significant. Sorry to hear it.")

# Eliza's recommendation printed to the console
# Response dependent on how_long and the possible_actions the user has tried
if int(how_long) >= 3:
    
    actions_not_taken = []  # Empty list used to store actions not taken
    
    # Eliza loops through possible_actions
    # Appends possible_actions with 'n' response to the actions_not_taken list
    for possible_actions_index in range(5):
        print("Have you tried..." + possible_actions[possible_actions_index]\
              + "? Please answer y or n:")
        action_taken = input()
        if action_taken == "n":
            actions_not_taken.append(possible_actions[possible_actions_index])

    # Any action in list action_not_taken is printed to the console
    if len(actions_not_taken) != 0:
        print("After careful analysis, Eliza300 advises you try: ")
        for actions_not_taken_index in range(len(actions_not_taken)):
            print(actions_not_taken[actions_not_taken_index])
            
    # If there are no actions in actions_not_taken, Eliza states
    # that there are no recommended actions
    else:
        print("Eliza has no recommended actions.")

# If how_long is less than 3, Eliza recommends user comes back when
# how_long is equal to at least 3 months.
else:
    print("Please return in " + str(3 - int(how_long)) + " months.")
