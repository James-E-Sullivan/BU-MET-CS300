from eliza300_5_functions_1 import *


def main():

    '''
    Postconditions
    1 (Welcome): A welcome message is on the console
    2 (user_complaint): user_complaint is the user's response in reply to
    "Please state your complaint:"
    3 (observed_complaint_types): observed_complaint_types =
    get_complaint_type(user_complaint)
    4 (Remedies displayed): The remedies in advice_per_type corresponding to
    observed_complaint_types are on the monitor, one line for each.

    Example: the user entered "I've been saddened by world conflicts," and the
    following is on the console after execution:
    Get out more.
    Take up a hobby that you love.
    Don't expect too much of people.
    Don't take offence easily.
    '''

    # (Welcome): Postcondition 1

    print("Thank you for using Eliza300, a fun therapy program.")

    # (user_compalint): Postcondition 2

    print("Please state your complaint:")
    user_complaint = input()

    # (observed_complaint_type): Postcondition 3

    observed_complaint_type = get_complaint_type(user_complaint)
    
    # (Remedies Displayed): Postcondition 4

    display_advice(observed_complaint_type)


main()
