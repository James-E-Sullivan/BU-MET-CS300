
advice_per_type = [
    ['Get out more.', 'Take up a hobby that you love.'],
    ["Don't expect too much of people.", "Don't take offence easily."],
    ['Get counseling.', "Don't delay action on counseling."]]

# Creates empty lists to store complaint types and keywords from text
complaint_types = []
key_words = []


def read_complaint_data():
    '''
    Intent: Get complaint_types and key_words from local ElizaData.txt

    Precondition ========

    ElizaData.txt is a local file consisting of paragraphs of the form

    On first line: 'Key Words for '<phrase describing a complaint category>
    On second line: <words, separated by blanks, that may occur within a
    description of the corresponding category>

    Example of ElizaData.txt:

    Key Words for Depression
    depress sad

    Key Words for Human Relations
    conflict argument mistreat

    Postconditions ========

    (1) complaint_types = list of the phrases in ElizaData.txt describing all
    complaint categories
    (2) key_words = list of lists of words in ElizaData.txt that may occur
    within phrases that describe the corresponding complaint category
    '''

    global complaint_types, key_words

    # Open ElizaData.txt file
    data_source = open('ElizaData.txt', 'r')

    # Read ElizaData.txt contents, place contents into file_contents
    for line_read in data_source:

        '''
        If the line contains a complaint type, the complaint type is
        parsed out into complaint_type_line and appended to complaint_types
        '''
        if 'Key Words for' in line_read:
            complaint_type_line = line_read.lstrip('Key Words for')
            complaint_type_line = complaint_type_line.strip('\n')
            complaint_types.append(complaint_type_line)

        # loop continues to next line if it is blank
        elif line_read == '\n':
            continue

        # key words are split into lists and appended to key_words
        else:
            key_words_line = line_read.split()
            key_words.append(key_words_line)

    # Close the file
    data_source.close()


read_complaint_data()   # need to execute this here

print("Printing complaint_types and key_words from ...runtime_data...")
print(complaint_types)
print(key_words)


def get_complaint_type(a_user_complaint):
    '''
    Precondition:
    1. a_user_complaint is a string
    2. complaint_type is a list of strings
    3. key_words is a list of lists of strings
    4. complaint_type and key_words are the same length

    Returns: observed_complaint_type, which consists of the indices in
    complaint_type that correspond to key_words elements partly in a
    user_complaint

    Example: if the user enters "I've been saddened by world conflicts",
    the function returns the set consisting of 0 and 1 because "I've been
    saddened ..." contains "sad" and "conflict".
    '''

    # The variable observed_complaint_type is the empty set
    observed_complaint_type = set()

    # loops through indices 0-2
    for complaint_type_index in range(len(complaint_types)):

        # loops through elements within the elements of key_words
        # at the given complaint_type_index
        for key_word_element in key_words[complaint_type_index]:

            # if an element at complaint_type_index is in the
            # user's complaint, complaint_type_index is added
            # to observed_complaint_type
            if key_word_element.lower() in a_user_complaint.lower():
                observed_complaint_type.add(complaint_type_index)
    
    return observed_complaint_type


def display_advice(complaint_indices):
    '''
    Precondition
    1. complaint_indices is a set of indices corresponding to user complaints
    2. advice_per_type is a list of list of strings
    3. advice_per_type elements correspond to complaint types (by index)
    '''

    # loops through set complaint_indices
    for advice_index in complaint_indices:

        # loops through all elements of the list within advice_per_type list
        # at the index corresponding to advice_index
        for advice_per_type_element in advice_per_type[advice_index]:
            print(advice_per_type_element)

