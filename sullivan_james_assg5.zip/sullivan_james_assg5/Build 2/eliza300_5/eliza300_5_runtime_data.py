# Creates empty lists to store complaint types and key words from
# ElizaData.txt
complaint_types = []
key_words = []


def read_complaint_data():
    '''
    Intent: Get complaint_types and key_words from local ElizaData.txt

    Precondition ========

    ElizaData.txt is a local file consisting of paragraphs of the form

    On first line: 'Key Words for '<phrase describing a complaint category>
    On second line: <words, separated by blanks, that may occur within a
    description of the corresponding category>

    Example of ElizaData.txt:

    Key Words for Depression
    depress sad

    Key Words for Human Relations
    conflict argument mistreat

    Postconditions ========

    (1) complaint_types = list of the phrases in ElizaData.txt describing all
    complaint categories
    (2) key_words = list of lists of words in ElizaData.txt that may occur
    within phrases that describe the corresponding complaint category
    '''

    global complaint_types, key_words

    # Open ElizaData.txt file
    data_source = open('ElizaData.txt', 'r')

    # Read ElizaData.txt contents, place contents into file_contents
    for line_read in data_source:

        '''
        If the line contains a complaint type, the complaint type is
        parsed out into complaint_type_line and appended to complaint_types
        '''
        if 'Key Words for' in line_read:
            complaint_type_line = line_read.lstrip('Key Words for')
            complaint_type_line = complaint_type_line.strip('\n')
            complaint_types.append(complaint_type_line)

        # loop continues to next line if it is blank
        elif line_read == '\n':
            continue

        # key words are split into lists and appended to key_words
        else:
            key_words_line = line_read.split()
            key_words.append(key_words_line)

    # Close the file
    data_source.close()


read_complaint_data()   # need to execute this here