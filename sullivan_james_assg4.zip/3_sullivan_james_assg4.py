# A list of types of emotional complaints and corresponding key words for each
complaint_type = ['Depression', 'Human Relations', 'Substance Abuse']

key_words = [['depress', 'sad', 'down'],
             ['conflict', 'argument', 'mistreat', 'quarrel'],
             ['drug', 'alcohol', 'drink', 'cocaine', 'opioid', 'heroin']]

advice_per_type = [
    ['Get out more.', 'Take up a hobby that you love.'],
    ["Don't expect too much of people.", "Don't take offence easily."],
    ['Get counseling.', "Don't delay action on counseling."]]

def get_complaint_type(a_user_complaint):
    '''
    Precondition:
    1. a_user_complaint is a string
    2. complaint_type is a list of strings
    3. key_words is a list of lists of strings
    4. complaint_type and key_words are the same length

    Returns: observed_complaint_type, which consists of the indices in
    complaint_type that correspond to key_words elements partly in a
    user_complaint

    Example: if the user enters "I've been saddened by world conflicts",
    the function returns the set consisting of 0 and 1 because "I've been
    saddened ..." contains "sad" and "conflict".
    '''

    # The variable observed_complaint_type is the empty set
    observed_complaint_type = set()

    # loops through indices 0-2
    for complaint_type_index in range(len(complaint_type)):

        # loops through elements within the elements of key_words
        # at the given complaint_type_index
        for key_word_element in key_words[complaint_type_index]:

            # if an element at complaint_type_index is in the
            # user's complaint, complaint_type_index is added
            # to observed_complaint_type
            if key_word_element.lower() in a_user_complaint.lower():
                observed_complaint_type.add(complaint_type_index)
    
    return observed_complaint_type

def display_advice(complaint_indices):
    '''
    Precondition
    1. complaint_indices is a set of indices corresponding to user complaints
    2. advice_per_type is a list of list of strings
    3. advice_per_type elements correspond to complaint types (by index)
    '''

    # loops through set complaint_indices
    for advice_index in complaint_indices:

        # loops through all elements of the list within advice_per_type list
        # at the index corresponding to advice_index
        for advice_per_type_element in advice_per_type[advice_index]:
            print(advice_per_type_element)


def main():

    '''
    Postconditions
    1 (Welcome): A welcome message is on the console
    2 (user_complaint): user_complaint is the user's response in reply to
    "Please state your complaint:"
    3 (observed_complaint_types): observed_complaint_types =
    get_complaint_type(user_complaint)
    4 (Remedies displayed): The remedies in advice_per_type corresponding to
    observed_complaint_types are on the monitor, one line for each.

    Example: the user entered "I've been saddened by world conflicts," and the
    following is on the console after execution:
    Get out more.
    Take up a hobby that you love.
    Don't expect too much of people.
    Don't take offence easily.
    '''

    # (Welcome): Postcondition 1

    print("Thank you for using Eliza300, a fun therapy program.")

    # (user_compalint): Postcondition 2

    print("Please state your complaint:")
    user_complaint = input()

    # (observed_complaint_type): Postcondition 3

    observed_complaint_type = get_complaint_type(user_complaint)
    
    # (Remedies Displayed): Postcondition 4

    display_advice(observed_complaint_type)

main()
