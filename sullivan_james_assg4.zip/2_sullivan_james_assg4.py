# A list of types of emotional complaints and corresponding key words for each
complaint_type = ['Depression', 'Human Relations', 'Substance Abuse']
key_words = [['depress', 'sad', 'down'],
             ['conflict', 'argument', 'mistreat', 'quarrel'],
             ['drug', 'alcohol', 'drink', 'cocaine', 'opioid', 'heroin']]

def get_complaint_type(a_user_complaint):
    '''
    Precondition:
    1. a_user_complaint is a string
    2. complaint_type is a list of strings
    3. key_words is a list of lists of strings
    4. complaint_type and key_words are the same length

    Returns: observed_complaint_type, which consists of the indices in
    complaint_type that correspond to key_words elements partly in a
    user_complaint

    Example: if the user enters "I've been saddened by world conflicts",
    the function returns the set consisting of 0 and 1 because "I've been
    saddened ..." contains "sad" and "conflict".
    '''

    # The variable observed_complaint_type is the empty set
    observed_complaint_type = set()

    # loops through indices 0-2
    for complaint_type_index in range(len(complaint_type)):

        # loops through elements within the elements of key_words
        # at the given complaint_type_index
        for key_word_element in key_words[complaint_type_index]:

            # if an element at complaint_type_index is in the
            # user's complaint, complaint_type_index is added
            # to observed_complaint_type
            if key_word_element.lower() in a_user_complaint.lower():
                observed_complaint_type.add(complaint_type_index)
    
    return observed_complaint_type


def main():

    '''
    Postconditions
    1 (Welcome): A welcome message is on the console
    2 (user_complaint): user_complaint is the user's response in reply to
    "Please state your complaint:"
    3 (observed_complaint_types): observed_complaint_types =
    get_complaint_type(user_complaint)
    4 (Indices displayed): observed_complaint_types is on the monitor
    '''

    # (Welcome): Postcondition 1

    print("Thank you for using Eliza300, a fun therapy program.")

    # (user_compalint): Postcondition 2

    print("Please state your complaint:")
    user_complaint = input()

    # (observed_complaint_type): Postcondition 3

    observed_complaint_type = get_complaint_type(user_complaint)
    
    # (Indices Displayed): Postcondition 4

    print(observed_complaint_type)

main()
