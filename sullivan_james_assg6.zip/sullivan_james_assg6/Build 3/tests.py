from functions import extend_partitions, all_partitions_of

# TESTS =========================================

# OF extend_partitions() ============

# test output with 1 element partitions
print("Test output with 1 element partitions")
print(extend_partitions([[[0]]], 11))
print("[[[0, 11]], [[0], [11]]]\n")

# test output using result from previous test
print("Test output using results from previous test")
print(extend_partitions([[[0, 11]], [[0], [11]]], 22))
print("\n")

# ===================================

# test output with 2 list partitions
print("Test output with 2 list partitions")
print(extend_partitions([[[0],[11]]], 22))
print("[[[0, 22], [11]], [[0], [11, 22]], [[0], [11], [22]]]\n")

# test output with strings
print("Test output with strings")
print(extend_partitions([[["John"], ["Sam"]]], "Mary"))
print("[[['John', 'Mary'], ['Sam']], [['John'], ['Sam', 'Mary']], [['John'], ['Sam'], ['Mary']]]\n")

# test output of with 3 list partitions
print("Test output with three list partitions")
print(extend_partitions([[[0], [11], [22]]], 33))
print("[[[0, 33], [11], [22]], [[0], [11, 33], [22]], [[0], [11], [22, 33]], [[0], [11], [22], [33]]]\n")

# test output when given multiple child partitions
print("Test output when given multiple child partitions")
print(extend_partitions([[[0, 11]], [[0], [11]]], 22))
print("[[[0, 11, 22]], [[0, 22], [11]], [[0], [11, 22]], [[0, 11], [22]], [[0], [11], [22]]]\n")

# ===============================================

# OF all_partitions_of() ============

# Test output with two elements
print("Test output with two elements")
print(all_partitions_of([0, 11]))
print("[[[0, 11]], [[0], [11]]]\n")

# Test output with three elements
print("Test output with three elements")
print(all_partitions_of([0, 11, 22]))
print("[[[0, 11, 22]], [[0, 22], [11]], [[0], [11, 22]], [[0, 11], [22]], [[0], [11], [22]]]\n")

# Test output with strings
print("Test output with strings")
print(all_partitions_of(["John", "Sam", "Mary"]))
print("[[['John', 'Sam', 'Mary']], [['John', 'Mary'], ['Sam']], "
      "[['John'], ['Sam', 'Mary']], [['John', 'Sam'], ['Mary']], "
      "[['John'], ['Sam'], ['Mary']]]\n")

print("[[[]]]<-->" + str(all_partitions_of([])) + '\n')  # one list--consisting of []

print("[[[333]]]<-->" + str(all_partitions_of([333])) + '\n')

print('all_partitions_of([0,22]):')
print(all_partitions_of([0,22]))
print("[[[0, 22]], [[0], [22]]]\n")

print('all_partitions_of([0,11,22]):')
print(all_partitions_of([0,11,22]))
print("[[[0, 22], [11]], [[0], [11, 22]], [[0, 11, 22]], [[0], [11], [22]], [[0, 11], [22]]]\n")

print('all_partitions_of([0,11,22,33]):')
print(all_partitions_of([0,11,22,33]))

print('all_partitions_of([7,8,1,3,5]):')
print(all_partitions_of([7,8,1,3,5]))