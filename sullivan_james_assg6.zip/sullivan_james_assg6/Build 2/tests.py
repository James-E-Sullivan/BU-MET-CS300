from functions import extend_partitions

# TESTS =========================================

# OF extend_partitions() ============

# test output with 2 list partitions
print(extend_partitions([[[0],[11]]], 22))
print("[[[0, 22], [11]], [[0], [11, 22]], [[0], [11], [22]]]\n")

# test output with strings
print(extend_partitions([[["John"], ["Sam"]]], "Mary"))
print("[[['John', 'Mary'], ['Sam']], [['John'], ['Sam', 'Mary']], [['John'], ['Sam'], ['Mary']]]\n")

# test output of with 3 list partitions
print(extend_partitions([[[0], [11], [22]]], 33))
print("[[[0, 33], [11], [22]], [[0], [11, 33], [22]], [[0], [11], [22, 33]], [[0], [11], [22], [33]]]\n")

# test output when given partitions with multiple elements
print(extend_partitions([[[0, 11]], [[0], [11]]], 22))
print("[[[0, 11, 22]], [[0, 22], [11]], [[0], [11, 22]], [[0, 11], [22]], [[0], [11], [22]]]\n")